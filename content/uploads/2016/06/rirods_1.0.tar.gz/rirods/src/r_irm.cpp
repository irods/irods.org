/*
 * r_irm.cpp
 *
 *  Created on: Jan 15, 2016
 *      Author: Radovan Chytracek
 */

#include <Rinterface.h>
#include <Rcpp.h>
using namespace Rcpp;

/*** Copyright (c), The Regents of the University of California            ***
 *** For more information please refer to files in the COPYRIGHT directory ***/
/*
 * irm - The irods rm utility
 */

#include "rodsClient.h"
#include "parseCommandLine.h"
#include "rodsPath.h"
#include "rmUtil.h"

//' imkdir
//' Creates a new directory in iRODS
//' @param rods_path The iRODS new directory path
//' @param recursive Remove all recursively
//' @param verbose   Verbose output
//' @param force     Skip trash bin, directly delete the iRODS object(s)
//'
// [[Rcpp::export]]
int irm( std::string rods_path="", bool recursive=false, bool verbose=false, bool force=false )
{
    int status;
    rodsEnv myEnv;
    rErrMsg_t errMsg;
    rcComm_t *conn;
    rodsArguments_t myRodsArgs;
    rodsPathInp_t rodsPathInp;

    // Initialize the iRODS input path object
    memset( &rodsPathInp, 0, sizeof( rodsPathInp_t ) );

    // We have to reset all to 0s because we do not use
    // the "parse_program_options(...)" function
    // The rmUtil(...) function expects positional arguments parser initializing it beforehand
    memset( &myRodsArgs, 0, sizeof( rodsArguments_t ) );

    if ( rods_path.empty() )
    {
        ::Rf_error( "[irm] no rods_path input\n" );
        return( 2 );
    }
    if(verbose)
    	myRodsArgs.verbose = 1;
    if(recursive)
    	myRodsArgs.recursive = 1;
    if(force)
    	myRodsArgs.force = 1;

    status = getRodsEnv( &myEnv );

    if ( status < 0 ) {
    	::Rf_error( "[irm] getRodsEnv error %d. ", status );
        return( 1 );
    }

    conn = rcConnect( myEnv.rodsHost, myEnv.rodsPort, myEnv.rodsUserName, myEnv.rodsZone, 1, &errMsg );

    if ( conn == NULL ) {
        exit( 2 );
    }

    status = clientLogin( conn );
    if ( status != 0 ) {
        rcDisconnect( conn );
        exit( 7 );
    }

    // Prepare the path for rmUtil(...)
    status = 0;
    rodsPath_t r_path;
    memset( &r_path, 0, sizeof( rodsPath_t ) );

    status = addSrcInPath((rodsPathInp_t*)(&rodsPathInp), rods_path.c_str());
    status = parseRodsPath( &(rodsPathInp.srcPath[0]), &myEnv );
    if( status < 0 ) {
    	::Rf_error("[irm] Error: %d : invalid iRODS src_path %s!\n", status, rodsPathInp.srcPath[0]);
    	return status;
    }

    status = rmUtil( conn, &myRodsArgs, &rodsPathInp );

    printErrorStack( conn->rError );
    rcDisconnect( conn );

    if ( ( USER_SOCK_CONNECT_ERR - 1000 ) < status && status <= USER_SOCK_CONNECT_ERR ) {
        ::Rf_error( "Remote resource may be unavailable %d.\n", status );
    }

    if ( status < 0 ) {
        return( 3 );
    }
    else {
        return( 0 );
    }

}

